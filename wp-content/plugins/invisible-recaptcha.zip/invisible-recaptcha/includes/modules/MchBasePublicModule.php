<?php
/**
 * Copyright (c) 2016 Ultra Community (http://www.ultracommunity.com)
 */

namespace InvisibleReCaptcha\MchLib\Modules;

abstract class MchBasePublicModule extends MchBaseModule
{
	protected function __construct()
	{
		parent::__construct();
	}
}