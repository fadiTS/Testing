<?php

include_once QODE_NEWS_SHORTCODES_PATH.'/layout3/widget/functions.php';
include_once QODE_NEWS_SHORTCODES_PATH.'/layout3/widget/layout3.php';